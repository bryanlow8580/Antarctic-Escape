#include "rectangle_2D.h"

Rectangle_2D::Rectangle_2D(float height, float width, Vector_2D translation)
	: Collider(height, width, translation)
{

}

Rectangle_2D::~Rectangle_2D()
{

}